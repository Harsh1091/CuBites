 <footer class="footer" style="text-align: center;">Developed by Students of Chandigarh University @2023 </footer>
